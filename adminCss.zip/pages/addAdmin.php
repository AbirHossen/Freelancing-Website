<?php

    include 'admin_index.php';




?>



<head>
    <title>Add Admin | FreelancerBD</title>
</head>

<div class="new">

    <form action="#"  method="post" >
        <div class="first_block">
            <h2>Add Admin</h2>
            <hr>
            <p >Name</p>
            <input type="text" id="name" placeholder="Input Admin Name Here(Max-10)" name="adminName" onInput="checkLength(10,this)">
            <p>Password</p>
            <input id="pass" type="text" placeholder="Password Has to be of 8 character" name="adminPass" onInput="checkLength(8,this)" >

            <input type="submit"   value="Submit" >


        </div>
    </form>



</div>