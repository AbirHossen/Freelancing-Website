<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../bootstrap-3.3.7/css/bootstrap.css">
        <script src="../js/jquery.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">
        <script src="../js/popper.js"></script>
        <script src="../bootstrap-3.3.7/js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="../adminCss/style.css">
   