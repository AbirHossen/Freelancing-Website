
<div id="container-fluid">
    
    <div class="sidebar" id=sidebarMargin>
        <ul>
            
            <a href="admin_index.php">
                <li>DASHBOARD
                </li>
            </a>
            <a href="">
                <li>ADMINS
                    <ul>
                        <a href="#"><li>ADD ADMIN</li></a>
                        <a href="#"><li>UPDATE INFO</li></a>
                        <a href="#"><li>REMOVE ADMIN</li></a>
						<a href="#"><li>ADMIN RECORDS</li></a>
                    </ul>
                </li>
            </a>
            <a href="">
                <li>DEVELOPERS
                    <ul>
                        <a href="#"><li>SHOW ALL DEVELOPERS</li></a>
                        <a href="#"><li>REMOVE DEVELOPERS</li></a>
                    </ul>
                </li>
            </a>

            <a href="">
                <li>CLIENTS
                    <ul>
                        <a href="#"><li>SHOW ALL CLIENTS</li></a>
                        <a href="#"><li>REMOVE CLIENTS</li></a>
                    </ul>
                </li>
            </a>

            <a href="">
                <li>REPORTS
                </li>
            </a>

            <a href="#">
                <li>TRANSACTIONS</li>
            </a>

               <a href="">
                <li>LOGISTICS
                </li>
            </a>

            
        </ul>
    </div>


