<form action="logout.php" method="post">
<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <a href="admin_index.php" class="navbar-brand">FreelancerBD</a>
        <ul class="nav navbar-nav navbar-right">
            <button class="btn btn-danger navbar-btn  btn-md" id=loginRedirect>Logout</button>
        </ul>
    </div>
</nav></form>


