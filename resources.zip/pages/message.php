<?php 
include 'admin_index.php';
?>
<head><title>Message | FreelancerBD</title></head>


<div class="new">

    <form action="#" enctype="multipart/form-data" method="post">
        <div class="first_block">
            <h2>Message Box</h2>
            <hr>
            <p>UserID</p>
            <input type="text" placeholder="Input Id here" name="" id="id">
            
            <textarea class="form-control" rows="5" id="comment">You have been granted tk 500 for good credit bonus!! COngratulations!!
            </textarea>


            <input type="submit" class="" value="Send" ">




        </div>
    </form>



</div>