<?php 
include 'admin_index.php';
?>
<head><title>Admin Records | FreelancerBD</title></head>

<div class="new">
    
        <table border = "1" cellpadding = "5" cellspacing = "5" style="width:60%;text-align:center">
         <tr>
            <th >From</th>
            <th>Against</th>
             <th>JobID</th>
             <th>Message</th>
             <th>Time</th>
             <th>Action</th>
             
         </tr>
         <tr>
            <td>user01</td>
            <td>client01</td>
            <td>graph353</td>
             <td>This is a sample text report against sample</td>
             <td>1h ago</td>
             <td><a href="#"><span class="glyphicon">&#xe014;</span></a> </td>
         </tr>
           <tr>
            <td>user02</td>
            <td>client02</td>
            <td>php566</td>
             <td>This is a sample text report against sample</td>
             <td>1h ago</td>
             <td><a href="#"><span class="glyphicon">&#xe014;</span></a> </td>
         </tr>
           <tr>
            <td>user03</td>
            <td>client03</td>
            <td>web95</td>
             <td>This is a sample text report against sample</td>
             <td>1h ago</td>
             <td><a href="#"><span class="glyphicon">&#xe014;</span></a> </td>
         </tr>
      </table>
    
</div>