<?php
include 'admin_index.php';


?>
<head><title>Update Admin | BookBrp</title></head>

<div class="new">

    <form action="#" >
        <div class="first_block">
            <h2>Update Admin</h2>
            <hr>
            <p>Admin Name</p>
            <input type="text" placeholder="Input Admin Username here" name="oldName" id="oldName">
            <p>New Admin Name</p>
            <input type="text" placeholder="Input New Username here" name="newAdminName" id="newName" >

            <p>New Password</p>
            <input type="text" placeholder="Input New Password  here" name="newAdinPass" id="pass">

            <input type="submit"  value="Update" style="background-color:#08ad19">




        </div>
    </form>



</div>