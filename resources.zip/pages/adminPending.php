<?php 
include 'admin_index.php';
?>
<head><title>Pending Jobs | FreelancerBD</title></head>

<div class="new">
        <div class="first_block"  style="margin:30px;margin-left:30px">
              <input type="text" placeholder="Post ID here" name="" id="">
            <input type="submit" class="" value="Search" >
    
        
        </div>
    
       

        <table border = "1" cellpadding = "5" cellspacing = "5" style="width:60%;text-align:center">
       
         <tr>
            <th >Title</th>
            <th>Client ID</th>
             <th>Amount</th>
             <th>Job Description</th>
             <th>Posted Time</th>
             <th>Bidders</th>
             <th>Action</th>
             
         </tr>
         <tr>
            <td>Looking for a Graphic Designer</td>
            <td>client489</td>
            <td>15000BDT</td>
             <td>For designing a company logo</td>
             <td>3d ago</td>
             <td>dev01,dev03,dev63</td>
             <td><a href="#"><span class="glyphicon">&#xe014;</span></a> </td>
         </tr>
          <tr>
            <td>Looking for Web developer</td>
            <td>client426</td>
            <td>2000BDT</td>
             <td>For modification of a code snippet</td>
             <td>2d ago</td>
             <td>dev01,dev03,dev63</td>
             <td><a href="#"><span class="glyphicon">&#xe014;</span></a> </td>
         </tr>
           <tr>
            <td>Looking for Web developer</td>
            <td>client426</td>
            <td>10000BDT</td>
             <td>For developing a module of a website</td>
             <td>1hr ago</td>
             <td>dev01,dev03,dev63</td>
             <td><a href="#"><span class="glyphicon">&#xe014;</span></a> </td>
         </tr>
      </table>
    
</div>