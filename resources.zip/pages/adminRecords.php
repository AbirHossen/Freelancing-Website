<?php 
include 'admin_index.php';
?>
<head><title>Admin Records | FreelancerBD</title></head>

<div class="new">
        <table border = "1" cellpadding = "5" cellspacing = "5" style="width:60%;text-align:center">
         <tr>
            <th >Username</th>
            <th>Name</th>
             <th>Last login</th>
         </tr>
         <tr>
            <td>admin01</td>
            <td>abir</td>
            <td>2h ago</td>
         </tr>
         <tr>
            <td>admin02</td>
            <td>arafat</td>
            <td>5h ago</td>
         </tr>
         <tr>
            <td>admin03</td>
            <td>koushik</td>
            <td>5h ago</td>
         </tr>
      </table>
    
</div>