<?php
include 'admin_index.php';


?>
<head><title>Remove Admin | BookBro</title></head>

<div class="new">

    <form action="#" enctype="multipart/form-data" method="post">
        <div class="first_block">
            <h2>Remove Admin by ID</h2>
            <hr>
            <p>Admin ID</p>
            <input type="text" placeholder="Input Admin Username here" name="adminID" id="id">


            <input type="submit" class="" value="Remove" style="background-color:#cc4128">




        </div>
    </form>



</div>