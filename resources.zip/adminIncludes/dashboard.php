
<div id="container-fluid">
    
    <div class="sidebar" id=sidebarMargin>
        <ul>
            
            <a href="adminDashboard.php">
                <li>DASHBOARD
                </li>
            </a>
            <a href="">
                <li>ADMINS
                    <ul>
                        <a href="addAdmin.php"><li>ADD ADMIN</li></a>
                        <a href="updateAdmin.php"><li>UPDATE INFO</li></a>
                        <a href="removeAdmin.php"><li>REMOVE ADMIN</li></a>
						<a href="adminRecords.php"><li>ADMIN RECORDS</li></a>
                    </ul>
                </li>
            </a>
            <a href="">
                <li>DEVELOPERS
                    <ul>
                        <a href="showDevelopers.php"><li>SHOW ALL DEVELOPERS</li></a>
                        <a href="removeDeveloper.php"><li>REMOVE DEVELOPERS</li></a>
                    </ul>
                </li>
            </a>

            <a href="">
                <li>CLIENTS
                    <ul>
                        <a href="showClients.php"><li>SHOW ALL CLIENTS</li></a>
                        <a href="removeClient.php"><li>REMOVE CLIENTS</li></a>
                    </ul>
                </li>
            </a>
             <a href="">
                <li>POSTS
                    <ul>
                        <a href="adminPending.php"><li>PENDING POSTS</li></a>
                    
                        <a href="adminOngoing.php"><li>ONGOING JOBS</li></a>
                    </ul>
                </li>
            </a>

            <a href="report.php">
                <li>REPORTS
                </li>
            </a>

            <a href="transaction.php">
                <li>TRANSACTIONS</li>
            </a>
           

               <a href="adminLogistics.php">
                <li>LOGISTICS
                </li>
            </a>

            
        </ul>
    </div>


